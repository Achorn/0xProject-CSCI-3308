console.log("Chrome extension go red?");
